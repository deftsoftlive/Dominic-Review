const options = {
	 filebrowserImageBrowseUrl: '/laravel-filemanager?type=Images',
	 filebrowserWindowWidth  : 800,
	 filebrowserWindowHeight : 500,
	 uiColor: '#eda208',
	 removePlugins: 'save, newpage',
	 allowedContent:true,
	 fillEmptyBlocks:true,
	 extraAllowedContent:'div, a, span, section, img'
};
